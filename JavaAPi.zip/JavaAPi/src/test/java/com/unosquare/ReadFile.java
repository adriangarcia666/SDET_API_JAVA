package com.unosquare;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;


public class ReadFile {

	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
		
		JSONParser json = new JSONParser();
		FileReader reader = new FileReader(".\\jsonfiles\\Register.json");
		Object obj = json.parse(reader);
		JSONObject JsonObject = (JSONObject)obj;
		
		String Jmail = (String) JsonObject.get("email");
		String Jpass = (String) JsonObject.get("password");
		
		
			System.out.println("email:"+Jmail);
			System.out.println("pass:"+Jpass);
			
			
			
			
			   
			  
		 }
		
		

	
	
	}


