package com.unosquare;

import org.testng.annotations.Test;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;




public class PostLogin throw IOException, ParseException  {
  @Test
  
	
	Response test = apiCore.PostLogin(".\\Json\\Register.json","/login");
	 Assert.assertEquals(200, test.statusCode()); 
	  
}
  @BeforeSuite
  public void beforeSuite() {
	  
	  apiCore = new ApiCore();
  }


