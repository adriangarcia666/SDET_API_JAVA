package com.unosquare;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.Reporter;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;




public class FirstAPITest {

@Test
public void f() {
	  
		RestAssured.baseURI = "https://reqres.in/api/";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.get("/users/2");
		
		int statusCode = response.getStatusCode();

		// Assert that correct status code is returned.
		Assert.assertEquals(statusCode,200);
		Reporter.log("Sucess 200 validation");
}



}