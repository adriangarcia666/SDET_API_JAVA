
package com.unosquare;

import org.testng.annotations.Test;
//import org.testng.Assert;
import org.testng.Reporter;
//import org.testng.annotations.BeforeMethod;

import io.restassured.http.ContentType;
//import io.restassured.matcher.ResponseAwareMatcher;
//import io.restassured.response.Response;
//import io.restassured.specification.RequestLogSpecification;
//import io.restassured.specification.RequestSpecification;

//import static io.restassured.matcher.RestAssuredMatchers.*;
//import static org.hamcrest.Matchers.*;
import static io.restassured.RestAssured.*;



public class unos {
	@Test
	public void f_Gherkin() {
		  
		  given()
		  .when()
		  .get("https://reqres.in/api/users/2")
		  .then().assertThat().statusCode(200).assertThat().contentType(ContentType.JSON);
		  
		  Reporter.log("Sucess 200 validation");
	}

}
