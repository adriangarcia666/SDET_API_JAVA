package com.unosquare;

import org.testng.annotations.Test;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.Reader;
import java.util.Iterator;

import io.restassured.RestAssured;
import io.restassured.internal.support.FileReader;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;




public class JsonFile {

	  
	  JSONParser json = new JSONParser();
	  FileReader reader = new FileReader();
	  reader = FileReader("C:\\Users\\adrian.garcia\\eclipse-workspace\\JavaAPi\\src\\test\\Register.json");
	  JSONObject obj = json.parse(reader);
	  
	  //System.out.println(obj);

	  
	  
	  
  }
}
