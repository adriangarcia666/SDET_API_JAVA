package com.unosquare;

import static io.restassured.RestAssured.given;

import org.testng.Reporter;
import org.testng.annotations.Test;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
//import io.restassured.response.Response;
//import io.restassured.specification.RequestSpecification;
//import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
//import static org.junit.Assert.assertThat;
//import static io.restassured.RestAssured.*;

public class NewTest {
  @Test
  public void f_Gherkin2() {
	  
	  
	  given()
	  .when()
	  	.get("https://reqres.in/api/users/2")
	  		.then()
	  		.assertThat().statusCode(200)
	  		.assertThat().contentType(ContentType.JSON)
	  		.assertThat().body("data.id", equalTo(2))
	  		.assertThat().body("data.email", equalTo("janet.weaver@reqres.in"))
	  		.assertThat().body("data.first_name", equalTo("Janet"))
	  		.assertThat().body("data.last_name", equalTo("Weaver"))
	  		.assertThat().body("data.avatar", equalTo("https://reqres.in/img/faces/2-image.jpg"));
	  		
	 
	  given()
	  .when()
	  	.get("https://reqres.in/api/unknown/2")
	  		.then()
	  		.assertThat().statusCode(200)
	  		.assertThat().body("data.id", equalTo(2))
	  		.assertThat().body("data.name", equalTo("fuchsia rose"))
	  		.assertThat().body("data.year", equalTo(2001))
	  		.assertThat().body("data.color", equalTo("#C74375"))
	  		.assertThat().body("data.pantone_value", equalTo("17-2031"));
	  		
	  
	  Reporter.log("Sucess 200 validation");
	  
	  
	  
	  
	  
	  
	  
  }
}
