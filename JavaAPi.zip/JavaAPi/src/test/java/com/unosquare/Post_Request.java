package com.unosquare;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileReader;
import java.io.IOException;


public class Post_Request {

	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub

		JSONParser json = new JSONParser();
		FileReader reader = new FileReader(".\\jsonfiles\\create.json");
		Object obj = json.parse(reader);
		JSONObject JsonObject = (JSONObject)obj;
		
		
		FileReader reader2 = new FileReader(".\\jsonfiles\\Login succeful.json");
		Object obj2 = json.parse(reader2);
		JSONObject JsonObject2 = (JSONObject)obj2;
		
		
		
		String Jname = (String) JsonObject.get("name");
		String Jjob = (String) JsonObject.get("job");
		
		System.out.println("name:"+Jname);
		System.out.println("job:"+Jjob);
		
		
		String Jmail = (String) JsonObject2.get("email");
		String Jpass = (String) JsonObject2.get("password");
		
		
			System.out.println("email:"+Jmail);
			System.out.println("pass:"+Jpass);
		
		
			
	}
	
	
	
	

}
